<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css'>
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark justify-content-center" style="background: linear-gradient(90deg, #023020 24%, rgba(6,121,24,1) 50%, rgba(6,120,24,1) 51%, rgba(18,51,23,1) 97%); z-index: 1000;">
  <div class="container-fluid mx-3"> 
    <div class="navbar-brand d-flex align-items-center">    
      <a href="<?php echo base_url(); ?>" class="navbar-logo">
        <img src="https://www.dar.gov.ph/assets/images/logo.svg" alt="Logo" width="50" height="50" class="d-inline-block align-top me-2">
      </a>
      <div class="ml-auto text-white lti-optool">
        LTI OpTool
      </div>
    </div>    
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto fs-5 fw-bold"> 
        <li class="nav-item">
          <a class="nav-link text-white" href="<?php echo base_url(); ?>">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="<?php echo base_url(); ?>about">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="<?php echo base_url(); ?>LandholdingInformation">Clients</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="#">Contact Us</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
</body>
</html> -->