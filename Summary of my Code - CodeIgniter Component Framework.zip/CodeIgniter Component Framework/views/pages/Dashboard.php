    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/vuetify@1.5.14/dist/vuetify.min.css'>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- Header Bar -->
    <div class="mb-16" style="background: linear-gradient(90deg, #023020 20%, rgba(6,121,24,1) 50%, rgba(6,120,24,1) 50%, rgba(18,51,23,1) 97%); z-index: 1;">
        <div class="container mx-auto text-center">
            <h1 class="text-2xl font-semibold text-white">DASHBOARD</h1>
        </div>
    </div>

    <div class="flex justify-center items-center" style="font-family: 'Roboto Condensed', sans-serif;">
        <div class="w-full max-w-screen-lg">

            <!-- Grid Layout -->
            <div class="grid grid-cols-3 gap-10">

                <!-- Box 1: LHID Count -->
                <div class="bg-white p-4 rounded-lg shadow-lg">
                    <h2 class="text-3xl font-bold text-blue-900 mb-4 flex items-center">
                        <svg class="w-8 h-8 text-blue-700 mr-2" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M13 16h-1v-4h-1m-1-4h3m4 6h2a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v3a2 2 0 002 2h4"></path>
                        </svg>
                        LandHolding Count
                    </h2>
                    <div class="text-4xl font-bold text-green-400 mb-4 flex items-center ml-3">
                        <svg class="w-8 h-8 text-blue-700 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 0 1-2.25 2.25M16.5 7.5V18a2.25 2.25 0 0 0 2.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 0 0 2.25 2.25h13.5M6 7.5h3v3H6v-3Z" />
                        </svg><?= $lhidcount ?>
                    </div>
                    <p class="text-gray-600">Content for LHID Count box goes here.</p>
                </div>


                <!-- Box 2: View LHID Details -->
                <div class="bg-white p-4 rounded-lg shadow-lg ">
                    <div class="flex items-center mb-4">
                        <h2 class="text-3xl font-bold text-blue-900 mb-4 flex items-center">
                            <svg class="w-8 h-8 text-blue-700 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m5.231 13.481L15 17.25m-4.5-15H5.625c-.621 0-1.125.504-1.125 1.125v16.5c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Zm3.75 11.625a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z" />
                            </svg>
                            View LHID Details
                        </h2>
                    </div>
                    <p class="text-gray-700 mb-4">Content for View LHID Details box goes here.</p>
                    <div class="text-right">
                        <a href="<?php echo base_url(); ?>LH_Dashboard#section-1">
                        <button class="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-6 rounded-full shadow-sm hover:shadow-md transition-shadow duration-300">
                            VIEW
                        </button>
                        </a>
                        <a href="<?php echo base_url(); ?>Landholding_Information">
                        <button class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-6 rounded-full shadow-sm hover:shadow-md transition-shadow duration-300">
                            VIEW
                        </button>
                        </a>
                    </div>
                </div>
                
                <!-- Box 3: History -->
                <div class="bg-white p-4 rounded-lg shadow-lg">
                    <div class="flex items-center mb-4">
                        <h2 class="text-3xl font-bold text-blue-900 mb-4 flex items-center">
                        <svg class="w-8 h-8 text-blue-700 mr-2" class="h-8 w-8 text-red-800"  width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">  <path stroke="none" d="M0 0h24v24H0z"/>  <polyline points="12 8 12 12 14 14" />  <path d="M3.05 11a9 9 0 1 1 .5 4m-.5 5v-5h5" /></svg>
                    History
                    </h2>
                    </div>
                    <p class="text-gray-700">Content for Recording Changes.</p>
                    <div class="text-right">
                        <a href="">
                        <button class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-6 rounded-full shadow-sm hover:shadow-md transition-shadow duration-300">
                            VIEW
                        </button>
                        </a>
                    </div>
                </div>

                <!-- Box 4: Excel View -->
                <div class="bg-white p-4 rounded-lg shadow-lg">
                    <div class="flex items-center mb-4">
                        <h2 class="text-3xl font-bold text-blue-900 mb-4 flex items-center">
                            <svg class="w-8 h-8 text-blue-700 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                              <path stroke-linecap="round" stroke-linejoin="round" d="M3.375 19.5h17.25m-17.25 0a1.125 1.125 0 0 1-1.125-1.125M3.375 19.5h7.5c.621 0 1.125-.504 1.125-1.125m-9.75 0V5.625m0 12.75v-1.5c0-.621.504-1.125 1.125-1.125m18.375 2.625V5.625m0 12.75c0 .621-.504 1.125-1.125 1.125m1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125m0 3.75h-7.5A1.125 1.125 0 0 1 12 18.375m9.75-12.75c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125m19.5 0v1.5c0 .621-.504 1.125-1.125 1.125M2.25 5.625v1.5c0 .621.504 1.125 1.125 1.125m0 0h17.25m-17.25 0h7.5c.621 0 1.125.504 1.125 1.125M3.375 8.25c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125m17.25-3.75h-7.5c-.621 0-1.125.504-1.125 1.125m8.625-1.125c.621 0 1.125.504 1.125 1.125v1.5c0 .621-.504 1.125-1.125 1.125m-17.25 0h7.5m-7.5 0c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125M12 10.875v-1.5m0 1.5c0 .621-.504 1.125-1.125 1.125M12 10.875c0 .621.504 1.125 1.125 1.125m-2.25 0c.621 0 1.125.504 1.125 1.125M13.125 12h7.5m-7.5 0c-.621 0-1.125.504-1.125 1.125M20.625 12c.621 0 1.125.504 1.125 1.125v1.5c0 .621-.504 1.125-1.125 1.125m-17.25 0h7.5M12 14.625v-1.5m0 1.5c0 .621-.504 1.125-1.125 1.125M12 14.625c0 .621.504 1.125 1.125 1.125m-2.25 0c.621 0 1.125.504 1.125 1.125m0 1.5v-1.5m0 0c0-.621.504-1.125 1.125-1.125m0 0h7.5" />
                            </svg>
                        CFdoc View</h2>
                    </div>
                    <p class="text-gray-700">Content for View Excel View.</p>
                    <div class="text-right">
                        <a href="<?php echo base_url(); ?>upload_form">
                        <button class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-6 rounded-full shadow-sm hover:shadow-md transition-shadow duration-300">
                            VIEW
                        </button>
                        </a>
                    </div>
                </div>

                <!-- Box 5: Downloads -->
                <div class="bg-white p-4 rounded-lg shadow-lg">
                    <div class="flex items-center mb-4">
                        <h2 class="text-3xl font-bold text-blue-900 mb-4 flex items-center">
                        <svg class="w-8 h-8 text-blue-700 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M7.5 7.5h-.75A2.25 2.25 0 0 0 4.5 9.75v7.5a2.25 2.25 0 0 0 2.25 2.25h7.5a2.25 2.25 0 0 0 2.25-2.25v-7.5a2.25 2.25 0 0 0-2.25-2.25h-.75m-6 3.75 3 3m0 0 3-3m-3 3V1.5m6 9h.75a2.25 2.25 0 0 1 2.25 2.25v7.5a2.25 2.25 0 0 1-2.25 2.25h-7.5a2.25 2.25 0 0 1-2.25-2.25v-.75" />
                        </svg>
                       Download \ Upload</h2>
                    </div>
                    <p class="text-gray-700">Upload / Download back-up Excel files.</p>
                    <div class="text-right">
                        <a href="<?php echo base_url(); ?>download">
                        <button class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-6 rounded-full shadow-sm hover:shadow-md transition-shadow duration-300">
                            VIEW
                        </button>
                        </a>
                    </div>
                </div>

                <!-- Box 6: Example Box -->
                <div class="bg-white p-4 rounded-lg shadow-lg">
                    <div class="flex items-center mb-4">
                        <h2 class="text-3xl font-bold text-blue-900 mb-1 flex items-center">
                        <svg class="w-8 h-8 text-blue-700 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M20.25 6.375c0 2.278-3.694 4.125-8.25 4.125S3.75 8.653 3.75 6.375m16.5 0c0-2.278-3.694-4.125-8.25-4.125S3.75 4.097 3.75 6.375m16.5 0v11.25c0 2.278-3.694 4.125-8.25 4.125s-8.25-1.847-8.25-4.125V6.375m16.5 0v3.75m-16.5-3.75v3.75m16.5 0v3.75C20.25 16.153 16.556 18 12 18s-8.25-1.847-8.25-4.125v-3.75m16.5 0c0 2.278-3.694 4.125-8.25 4.125s-8.25-1.847-8.25-4.125" />
                        </svg>
                       System Status</h2>
                    </div>
                    <div class="text-2xl font-bold text-black-200 mb-4 flex items-center ml-3">
                        <svg class="w-7 h-7 text-green-400 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                      <path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm.53 5.72a.75.75 0 0 0-1.06 0l-3 3a.75.75 0 1 0 1.06 1.06l1.72-1.72v5.69a.75.75 0 0 0 1.5 0v-5.69l1.72 1.72a.75.75 0 0 0 1.06-1.06l-3-3Z" clip-rule="evenodd"/>
                    </svg>
                    System Runnning
                    </div>
                    
                    <div class="text-right">
                        <a href="">
                        <button class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-6 rounded-full shadow-sm hover:shadow-md transition-shadow duration-300">
                            VIEW
                        </button>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
