<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Land Records</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.0.4/tailwind.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <style>
        section {
            display: none;
        }
        section:target {
            display: block;
        }
        .content-div {
            background-color: transparent;
            border: none;
            outline: none;
            font-weight: 600;
            font-size: 1.125rem;
            width: 100%;
            overflow: hidden;
            resize: none;
            white-space: pre-wrap; /* Allows wrapping of text */
        }
    </style>
</head>
<body class="">
    
<div class="flex">
    <aside class="w-81 min-h-screen bg-white shadow-md">
        <div class="py-6 px-4">
            <form method="get" action="<?php echo base_url('LH_Dashboard#section-1'); ?>" class="flex mb-6 p-1 rounded-full border border-gray-300 shadow-sm">
                <input 
                    type="text" 
                    name="search" 
                    class="flex-grow p-3 focus:outline-none bg-transparent rounded-full select-none" 
                    placeholder="Search..." 
                    value="<?php echo isset($search) ? $search : ''; ?>"
                />
                <button 
                    type="submit" 
                    class="ml-2 px-4 py-2 bg-blue-500 text-white rounded-full shadow-sm hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
                    Search
                </button>
            </form>

            <nav>
                <ul class="space-y-4">
                    <?php
                    $sections = [
                        "Identification and Location Data" => "person_pin_circle",
                        "Geographical Data" => "map",
                        "Land Area Information" => "terrain",
                        "Survey and Legal Status" => "gavel",
                        "Current Status and Description" => "assignment_turned_in",
                        "Target Years for Different Processes" => "timeline",
                        "Miscellaneous/Additional Information" => "info"
                    ];
                    $i = 1;
                    foreach ($sections as $title => $icon) {
                        echo '
                            <li class="bg-yellow-100 rounded-l-full cursor-pointer hover:bg-yellow-200">
                                <a href="#section-' . $i . '" class="flex items-center px-3 py-5">
                                    <i class="material-icons text-lg text-green-500 pr-3">' . $icon . '</i>
                                    <span class="text-blue-800 font-semibold">' . $title . '</span>
                                    <i class="material-icons text-black ml-auto">chevron_right</i>
                                </a>
                            </li>';
                        $i++;
                    }
                    ?>
                </ul>
            </nav>
        </div>
    </aside>
   
    <main class="flex-1">
        <?php if (!empty($records)) { 
            $row = $records[0];

        ?>
            <?php

            $sections = [
                    "Identification and Location Data" => [
                        "LHID" => empty($row['LHID']) ? 'Empty!' : htmlspecialchars($row['LHID']),
                        "Title Number" => empty($row['TitleNumber']) ? 'Empty!' : htmlspecialchars($row['TitleNumber']),
                        "Owner's Name" => empty($row['LOName']) ? 'Empty!' : htmlspecialchars($row['LOName']),
                        "Region" => empty($row['RegionName']) ? 'Empty!' : htmlspecialchars($row['RegionName']),
                        "Province" => empty($row['ProvinceName']) ? 'Empty!' : htmlspecialchars($row['ProvinceName']),
                        "Municipality/City" => empty($row['MCDName']) ? 'Empty!' : htmlspecialchars($row['MCDName']),
                        "Barangay" => empty($row['BarangayName']) ? 'Empty!' : htmlspecialchars($row['BarangayName'])
                    ],
                    "Geographical Data" => [
                        "Phase" => empty($row['Phase']) ? 'Empty!' : htmlspecialchars($row['Phase']),
                        "MOA" => empty($row['MOA']) ? 'Empty!' : htmlspecialchars($row['MOA']),
                        "Target Year" => empty($row['TargetYear']) ? 'Empty!' : htmlspecialchars($row['TargetYear']),
                        "Pipeline Year" => empty($row['PipelineYear']) ? 'Empty!' : htmlspecialchars($row['PipelineYear'])
                    ],
                    "Land Area Information" => [
                        "Total Area" => empty($row['TotalArea']) ? 'Empty!' : htmlspecialchars($row['TotalArea']),
                        "Computed Area" => empty($row['ComputedArea']) ? 'Empty!' : htmlspecialchars($row['ComputedArea']),
                        "Distributed Area" => empty($row['DistributedArea']) ? 'Empty!' : htmlspecialchars($row['DistributedArea']),
                        "New Land Size" => empty($row['NewLandSize']) ? 'Empty!' : htmlspecialchars($row['NewLandSize'])
                    ],
                    "Survey and Legal Status" => [
                        "Survey Number" => empty($row['SurveyNumber']) ? 'Empty!' : htmlspecialchars($row['SurveyNumber']),
                        "Lot Number" => empty($row['LotNumber']) ? 'Empty!' : htmlspecialchars($row['LotNumber']),
                        "CARPable" => empty($row['CARPable']) ? 'Empty!' : htmlspecialchars($row['CARPable']),
                        "NONCARPable" => empty($row['NONCARPable']) ? 'Empty!' : htmlspecialchars($row['NONCARPable']),
                        "Survey Status" => empty($row['SurveyStatus']) ? 'Empty!' : htmlspecialchars($row['SurveyStatus'])
                    ],
                    "Current Status and Description" => [
                        "Current Status" => empty($row['CurrentStatus']) ? 'Empty!' : htmlspecialchars($row['CurrentStatus']),
                        "Current Status Description" => empty($row['CurrentStatusDesc']) ? 'Empty!' : htmlspecialchars($row['CurrentStatusDesc'])
                    ],
                    "Target Years for Different Processes" => [
                        "CFDOC Target Year" => empty($row['CFDOCTargetYear']) ? 'Empty!' : htmlspecialchars($row['CFDOCTargetYear']),
                        "Survey Target Year" => empty($row['SurveyTargetYear']) ? 'Empty!' : htmlspecialchars($row['SurveyTargetYear']),
                        "Valuation Target Year" => empty($row['ValuationTargetYear']) ? 'Empty!' : htmlspecialchars($row['ValuationTargetYear']),
                        "Registration Target Year" => empty($row['RegistrationTargetYear']) ? 'Empty!' : htmlspecialchars($row['RegistrationTargetYear'])
                    ],
                    "Miscellaneous/Additional Information" => [
                        "Claim Folder Status Description" => empty($row['ClaimFolderStatusDesc']) ? 'Empty!' : htmlspecialchars($row['ClaimFolderStatusDesc']),
                        "Claim Folder Status Date" => empty($row['ClaimFolderStatusDate']) ? 'Empty!' : htmlspecialchars($row['ClaimFolderStatusDate']),
                        "Claim Folder Remarks" => empty($row['ClaimFolderRemarks']) ? 'Empty!' : htmlspecialchars($row['ClaimFolderRemarks']),
                        "Survey Status Description" => empty($row['SurveyStatusDesc']) ? 'Empty!' : htmlspecialchars($row['SurveyStatusDesc']),
                        "Survey Status Date" => empty($row['SurveyStatusDate']) ? 'Empty!' : htmlspecialchars($row['SurveyStatusDate']),
                        "Survey Remarks" => empty($row['SurveyRemarks']) ? 'Empty!' : htmlspecialchars($row['SurveyRemarks'])
                    ]
                ];

                $i = 1;
                foreach ($sections as $sectionTitle => $fields) {
                    echo '
                    <section id="section-' . $i . '" class="mb-8">
                        <div class="text-center mb-6 select-none">
                            <h2 class="bg-green-100 p-8 text-4xl font-bold uppercase text-blue-900">' . $sectionTitle . '</h2>
                        </div>
                        <div class="grid grid-cols-2 gap-3 px-3">';
                    foreach ($fields as $fieldTitle => $fieldValue) {
                        $fieldClass = $fieldValue === 'Empty!' ? 'text-red-500' : 'text-blue-900';
                        echo '
                        <div class="p-4">
                            <div class="text-lg font-semibold text-gray-500 select-none">' . $fieldTitle . '</div>
                            <div class="flex items-center">
                                <div id="copy-' . strtolower(str_replace(' ', '-', $fieldTitle)) . '" class="content-div ' . $fieldClass . '" readonly>' . htmlspecialchars($fieldValue) . '</div>
                                <button data-copy-to-clipboard-target="copy-' . strtolower(str_replace(' ', '-', $fieldTitle)) . '" class="ml-2 text-blue-500 hover:text-blue-700 mt-1 focus:outline-none">
                                    <i class="material-icons-outlined bg-transparent">content_copy</i>
                                </button>
                            </div>
                        </div>';
                    }
                    echo '
                        </div>
                    </section>';
                    $i++;
                }
            ?>

            <?php } else { ?>
                <div class="text-center mt-3">No Records Found</div>
            <?php } ?>

            <!-- Flash Messages -->
            <?php if ($this->session->flashdata('success')) { ?>
                <div class="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 w-1/2 text-center bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded flex items-center justify-center flash-message" role="alert">
                    <span class="material-icons mr-2">check_circle</span> Successfully Added
                </div>
            <?php } ?>
            <?php if ($this->session->flashdata('deleted')) { ?>
                <div class="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 w-1/2 text-center bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded flex items-center justify-center flash-message" role="alert">
                    <span class="material-icons mr-2">delete</span> Successfully Deleted
                </div>
            <?php } ?>
            <?php if ($this->session->flashdata('error')) { ?>
                <div class="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 w-1/2 text-center bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded flex items-center justify-center flash-message" role="alert">
                    <span class="material-icons mr-2">error</span> Failed!
                </div>
            <?php } ?>

            <!-- JavaScript for Fading Out the Messages -->
            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    setTimeout(function() {
                        var flashMessages = document.querySelectorAll('.flash-message');
                        flashMessages.forEach(function(message) {
                            message.style.transition = "opacity 1s ease";
                            message.style.opacity = "0";
                            setTimeout(function() {
                                message.remove();
                            }, 1000);
                        });
                    }, 1000);
                });
            </script>

    </main>
</div>

<!-- Floating Button -->
<div class="fixed bottom-8 right-8 z-50">
    <!-- Button -->
    <div class="relative">
        <input type="checkbox" id="toggle" class="hidden">
        <label for="toggle" class="select-none flex items-center justify-center bg-blue-500 text-white p-6 rounded-full shadow-md cursor-pointer">
            <span class="material-icons-outlined text-xl">more_vert</span>
        </label>
        <!-- Button Group -->
        <div id="btnGroup" class="hidden absolute bottom-20 right-0 bg-white rounded-md shadow-md">
            <?php if(isset($row['LHID'])) { ?> <!-- Check if $row is set -->
                <a href="<?= base_url() ?>Landholding/edit_record/<?= $row['LHID'] ?>" class="block px-4 py-3 text-blue-500 hover:bg-blue-100 hover:text-blue-700 border-b border-gray-200">Edit</a>

                <a href="<?= base_url() ?>Landholding/add_record/<?= $row['LHID'] ?>" class="block px-4 py-3 text-green-500 hover:bg-green-100 hover:text-green-400 border-b border-gray-200">Add</a>

                <a href="<?=base_url()?>landrecords/delete/<?=$row['LHID']?>" onclick="return confirm('Are you sure want to delete this record ?')" class="block px-4 py-3 text-red-500 hover:bg-red-100 hover:text-red-700">Delete</a>
            <?php } ?>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('[data-copy-to-clipboard-target]').forEach(button => {
    button.addEventListener('click', () => {
        const targetId = button.getAttribute('data-copy-to-clipboard-target');
        const target = document.getElementById(targetId);
        const range = document.createRange();
        range.selectNodeContents(target);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
        document.execCommand('copy');
        button.innerHTML = `
            <svg class="w-3 h-3 text-blue-500 me-1.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 12">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 5.917 5.724 10.5 15 1.5"/>
            </svg>
        `;
        setTimeout(() => {
            button.innerHTML = '<i class="material-icons-outlined">content_copy</i>';
        }, 500);
    });
});

document.getElementById('toggle').addEventListener('change', function() {
    document.getElementById('btnGroup').classList.toggle('hidden', !this.checked);
});
</script>

</body>
</html>
