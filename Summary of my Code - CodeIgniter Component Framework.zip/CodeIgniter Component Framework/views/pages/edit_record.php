<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Land Record</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="font-sans">
    <div class="flex justify-center">
        <div class="w-full">
            <h5 style="font-size: 3rem;" class="text-center font-bold text-gray-800 py-5">Edit Land Record</h5>
            <div class="bg-white px-20">
                
                <form method="post" action="<?= base_url('Landholding/edit_record/' . $record->LHID) ?>">
                    
                    <!-- IDENTIFICATION AND LOCATION DATA -->
                    <div class="mb-8">
                        <h6 style="font-size: 2rem;" class="font-semibold text-gray-800 mb-4 border-b-2 border-gray-300 pb-2">Identification and Location Data</h6>
                        <div class="grid grid-cols-1 gap-4 md:grid-cols-3 px-10">
                            <div class="form-group py-2">
                                <label for="LHID" class="text-gray-700 select-none font-semibold">LHID:</label>
                                <input type="text" name="LHID" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md text-blue-800" value="<?= isset($record->LHID) ? $record->LHID : '' ?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="TitleNumber" class="text-gray-700 select-none font-semibold">Title Number:</label>
                                <input type="text" name="TitleNumber" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 text-blue-800" value="<?=isset($record->TitleNumber) ? $record->TitleNumber : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="LOName" class="text-gray-700 select-none font-semibold">Owner's Name:</label>
                                <input type="text" name="LOName" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->LOName) ? $record->LOName : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="RegionName" class="text-gray-700 select-none font-semibold">Region:</label>
                                <input type="text" name="RegionName" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->RegionName) ? $record->RegionName : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="ProvinceName" class="text-gray-700 select-none font-semibold">Province:</label>
                                <input type="text" name="ProvinceName" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->ProvinceName) ? $record->ProvinceName : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="MCDName" class="text-gray-700 select-none font-semibold">Municipality/City:</label>
                                <input type="text" name="MCDName" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->MCDName) ? $record->MCDName : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="BarangayName" class="text-gray-700 select-none font-semibold">Barangay:</label>
                                <input type="text" name="BarangayName" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->BarangayName) ? $record->BarangayName : ''?>">
                            </div>
                        </div>
                    </div>
                    
                    <!-- GEOGRAPHICAL DATA -->
                    <div class="mb-8">
                        <h6 style="font-size: 2rem;" class="font-semibold text-gray-800 mb-4 border-b-2 border-gray-300 pb-2">Geographical Data</h6>
                        <div class="grid grid-cols-1 gap-4 md:grid-cols-2 px-10">
                            <div class="form-group py-2">
                                <label for="Phase" class="text-gray-700 select-none font-semibold">Phase:</label>
                                <input type="text" name="Phase" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->Phase) ? $record->Phase : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="MOA" class="text-gray-700 select-none font-semibold">MOA:</label>
                                <input type="text" name="MOA" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->MOA) ? $record->MOA : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="TargetYear" class="text-gray-700 select-none font-semibold">Target Year:</label>
                                <input type="text" name="TargetYear" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->TargetYear) ? $record->TargetYear : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="PipelineYear" class="text-gray-700 select-none font-semibold">Pipeline Year:</label>
                                <input type="text" name="PipelineYear" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->PipelineYear) ? $record->PipelineYear : ''?>">
                            </div>
                        </div>
                    </div>
                    
                    <!-- LAND AREA INFORMATION -->
                    <div class="mb-8">
                        <h6 style="font-size: 2rem;" class="font-semibold text-gray-800 mb-4 border-b-2 border-gray-300 pb-2">Land Area Information</h6>
                        <div class="grid grid-cols-1 gap-4 md:grid-cols-2 px-10">
                            <div class="form-group py-2">
                                <label for="TotalArea" class="text-gray-700 select-none font-semibold">Total Area:</label>
                                <input type="text" name="TotalArea" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->TotalArea) ? $record->TotalArea : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="ComputedArea" class="text-gray-700 select-none font-semibold">Computed Area:</label>
                                <input type="text" name="ComputedArea" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->ComputedArea) ? $record->ComputedArea : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="DistributedArea" class="text-gray-700 select-none font-semibold">Distributed Area:</label>
                                <input type="text" name="DistributedArea" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->DistributedArea) ? $record->DistributedArea : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="NewLandSize" class="text-gray-700 select-none font-semibold">New Land Size:</label>
                                <input type="text" name="NewLandSize" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->NewLandSize) ? $record->NewLandSize : ''?>">
                            </div>
                        </div>
                    </div>
                    
                    <!-- SURVEY AND LEGAL STATUS -->
                    <div class="mb-8">
                        <h6 style="font-size: 2rem;" class="font-semibold text-gray-800 mb-4 border-b-2 border-gray-300 pb-2">Survey and Legal Status</h6>
                        <div class="grid grid-cols-1 gap-4 md:grid-cols-2 px-10">
                            <div class="form-group py-2">
                                <label for="SurveyNumber" class="text-gray-700 select-none font-semibold">Survey Number:</label>
                                <input type="text" name="SurveyNumber" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->SurveyNumber) ? $record->SurveyNumber : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="LotNumber" class="text-gray-700 select-none font-semibold">Lot Number:</label>
                                <input type="text" name="LotNumber" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->LotNumber) ? $record->LotNumber : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="CARPable" class="text-gray-700 select-none font-semibold">CARPable:</label>
                                <input type="text" name="CARPable" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->CARPable) ? $record->CARPable : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="NONCARPable" class="text-gray-700 select-none font-semibold">NONCARPable:</label>
                                <input type="text" name="NONCARPable" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->NONCARPable) ? $record->NONCARPable : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="SurveyStatus" class="text-gray-700 select-none font-semibold">Survey Status:</label>
                                <input type="text" name="SurveyStatus" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->SurveyStatus) ? $record->SurveyStatus : ''?>">
                            </div>
                        </div>
                    </div>
                    
                    <!-- CURRENT STATUS AND DESCRIPTION -->
                    <div class="mb-8">
    <h6 style="font-size: 2rem;" class="font-semibold text-gray-800 mb-4 border-b-2 border-gray-300 pb-2">Current Status and Description</h6>
    <div class="grid grid-cols-2 gap-4">
        <div class="form-group py-2">
            <label for="CurrentStatus" class="text-gray-700 select-none font-semibold">Current Status:</label>
            <input type="text" name="CurrentStatus" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-normal border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->CurrentStatus) ? $record->CurrentStatus : ''?>">
        </div>
        <div class="form-group py-2">
            <label for="CurrentStatusDesc" class="text-gray-700 select-none font-semibold">Current Status Description:</label>
            <textarea name="CurrentStatusDesc" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-normal border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800"><?=isset($record->CurrentStatusDesc) ? $record->CurrentStatusDesc : ''?></textarea>
        </div>
    </div>
</div>

                    
                    <!-- TARGET YEARS FOR DIFFERENT PROCESSES -->
                    <div class="mb-8">
                        <h6 style="font-size: 2rem;" class="font-semibold text-gray-800 mb-4 border-b-2 border-gray-300 pb-2">Target Years for Different Processes</h6>
                        <div class="grid grid-cols-1 gap-4 md:grid-cols-2 px-10">
                            <div class="form-group py-2">
                                <label for="CFDOCTargetYear" class="text-gray-700 select-none font-semibold">CFDOC Target Year:</label>
                                <input type="text" name="CFDOCTargetYear" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->CFDOCTargetYear) ? $record->CFDOCTargetYear : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="SurveyTargetYear" class="text-gray-700 select-none font-semibold">Survey Target Year:</label>
                                <input type="text" name="SurveyTargetYear" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->SurveyTargetYear) ? $record->SurveyTargetYear : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="ValuationTargetYear" class="text-gray-700 select-none font-semibold">Valuation Target Year:</label>
                                <input type="text" name="ValuationTargetYear" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->ValuationTargetYear) ? $record->ValuationTargetYear : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="RegistrationTargetYear" class="text-gray-700 select-none font-semibold">Registration Target Year:</label>
                                <input type="text" name="RegistrationTargetYear" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->RegistrationTargetYear) ? $record->RegistrationTargetYear : ''?>">
                            </div>
                        </div>
                    </div>
                    
                    <!-- MISCELLANEOUS/ADDITIONAL INFORMATION -->
                    <div class="mb-8">
                        <h6 style="font-size: 2rem;" class="font-semibold text-gray-800 mb-4 border-b-2 border-gray-300 pb-2">Miscellaneous/Additional Information</h6>
                        <div class="grid grid-cols-2 gap-4 px-10">
                            <div class="form-group py-2">
                                <label for="ClaimFolderStatusDesc" class="text-gray-700 select-none font-semibold">Claim Folder Status Description:</label>
                                <input type="text" name="ClaimFolderStatusDesc" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->ClaimFolderStatusDesc) ? $record->ClaimFolderStatusDesc : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="ClaimFolderStatusDate" class="text-gray-700 select-none font-semibold">Claim Folder Status Date:</label>
                                <input type="text" name="ClaimFolderStatusDate" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->ClaimFolderStatusDate) ? $record->ClaimFolderStatusDate : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="ClaimFolderRemarks" class="text-gray-700 select-none font-semibold">Claim Folder Remarks:</label>
                                <input type="text" name="ClaimFolderRemarks" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->ClaimFolderRemarks) ? $record->ClaimFolderRemarks : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="SurveyStatusDesc" class="text-gray-700 select-none font-semibold">Survey Status Description:</label>
                                <input type="text" name="SurveyStatusDesc" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->SurveyStatusDesc) ? $record->SurveyStatusDesc : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="SurveyStatusDate" class="text-gray-700 select-none font-semibold">Survey Status Date:</label>
                                <input type="text" name="SurveyStatusDate" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->SurveyStatusDate) ? $record->SurveyStatusDate : ''?>">
                            </div>
                            <div class="form-group py-2">
                                <label for="SurveyRemarks" class="text-gray-700 select-none font-semibold">Survey Remarks:</label>
                                <input type="text" name="SurveyRemarks" class="form-control bg-transparent outline-none font-semibold text-lg w-full overflow-hidden resize-none whitespace-pre-wrap border-b border-gray-300 focus:border-gray-500 rounded-md focus:outline-none text-blue-800" value="<?=isset($record->SurveyRemarks) ? $record->SurveyRemarks : ''?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-8">
                        <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">Submit</button>
                    </div>
                </form>
                
                <?php if ($this->session->flashdata('error')) { ?>
                    <div class="bg-red-500 text-white p-4 rounded mt-4">
                        Failed to Update Record!
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA"></script>
</body>
</html>
