<?php
class Pages extends CI_Controller {
    
}
?>
