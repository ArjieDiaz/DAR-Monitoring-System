<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

require_once 'vendor/autoload.php';

class Landholding extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Landholding_model');
    }

    public function view($page = 'Dashboard') {
        if (!file_exists(APPPATH.'views/pages/'.$page.'.php')) {
            show_404();
        }

        $data['title'] = ucfirst($page);

        if ($page == 'Dashboard') {
            $data['lhidcount'] = $this->Landholding_model->countLandrecords();
        }

        $search = $this->input->get('search', TRUE); // TRUE for XSS filtering
        $data['search'] = $search;

        if ($search) {
            $data['records'] = $this->Landholding_model->search_data($search);
        } else {
            $data['records'] = $this->Landholding_model->fetch_data();
        }

        $this->load->view('templates/sidebar');
        $this->load->view('pages/'.$page, $data);
        $this->load->view('templates/footer');
    }

    public function fetchdata() {
        $data = $this->Landholding_model->fetch_data();

        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($data));
    }

    public function edit_record($LHID) {
        $this->form_validation->set_rules('TitleNumber', 'Title Number', 'required');
        $this->form_validation->set_rules('LOName', 'LO Name', 'required');

        if ($this->form_validation->run() === FALSE) {
            $data['record'] = $this->Landholding_model->get_record($LHID);
            $this->load->view('pages/edit_record', $data);
        } else {
            $data = $this->input->post(NULL, TRUE); // TRUE for XSS filtering

            if ($this->Landholding_model->update_record($LHID, $data)) {
                $this->session->set_flashdata('success', 'Successfully Updated Record!');
                redirect('Landholding/view/LH_Dashboard#section-1');
            } else {
                $this->session->set_flashdata('error', 'Failed to Update Record!');
                redirect('Landholding/edit_record/' . $LHID);
            }
        }
    }

    public function add_record() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = $this->input->post(NULL, TRUE); // TRUE for XSS filtering
            if ($this->Landholding_model->insert_record($data)) {
                $this->session->set_flashdata('success', 'Successfully Added');
                redirect(base_url('landholding/view/LH_Dashboard'));
            } else {
                $this->session->set_flashdata('error', 'Error');
                $this->load->view('pages/add_record');
            }
        } else {
            $this->load->view('pages/add_record');
        }
    }

    public function delete($id) {
        if (is_numeric($id)) {
            if ($this->Landholding_model->deleteRecord($id)) {
                $this->session->set_flashdata('deleted', 'Successfully Deleted');
            } else {
                $this->session->set_flashdata('error', 'Error');
            }
            redirect(base_url('landholding/view/LH_Dashboard#section-1'));
        }
    }

    public function view_tables() {
        $data['title'] = 'Database Tables';
        $data['tables'] = $this->Landholding_model->get_tables();

        $this->load->view('templates/header', $data);
        $this->load->view('pages/download', $data);
        $this->load->view('templates/footer');
    }

    public function download_table($table_name) {
        $data = $this->Landholding_model->get_table_data($table_name);

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        if (!empty($data)) {
            $columns = array_keys($data[0]);
            $columnLetter = 'A';
            foreach ($columns as $column) {
                $sheet->setCellValue($columnLetter . '1', $column);
                $columnLetter++;
            }

            $rowNumber = 2;
            foreach ($data as $row) {
                $columnLetter = 'A';
                foreach ($row as $cell) {
                    $sheet->setCellValue($columnLetter . $rowNumber, $cell);
                    $columnLetter++;
                }
                $rowNumber++;
            }
        }

        $writer = new Xlsx($spreadsheet);
        $filename = $table_name . '.xlsx';

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
        exit;
    }
}
