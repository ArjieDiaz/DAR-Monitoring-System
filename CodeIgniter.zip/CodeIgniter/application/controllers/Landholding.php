<?php

class Landholding extends CI_Controller {

    public function fetchdata() {
        // SQL query to fetch data from your new table
        $query = $this->db->get('landrecords');
        
        $data = $query->result_array();

        // Return data in JSON format
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($data));
    }

}
