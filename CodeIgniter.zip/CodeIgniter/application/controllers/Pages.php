<?php
class Pages extends CI_Controller {
    public function view($page = 'Landholding_Information') {
        if (!file_exists(APPPATH.'views/pages/'.$page.'.php')) {
            show_404();
        }

        // Load the model
        // $this->load->model('Page_model');
        // Set the title
        $data['title'] = ucfirst($page);

        // Load views
        // $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('pages/'.$page, $data);
        $this->load->view('templates/footer');
    }
}
?>
