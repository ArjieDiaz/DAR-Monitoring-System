<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Landholding_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function fetch_data() {
        $query = $this->db->get('landrecords');
        return $query->result_array();
    }

    public function search_data($search) {
        $this->db->like('LHID', $search);
        $this->db->or_like('TitleNumber', $search);
        $this->db->or_like('LOName', $search);
        $query = $this->db->get('landrecords');
        return $query->result_array();
    }

    public function countLandrecords() {
        return $this->db->count_all('landrecords');
    }

    public function get_record($LHID) {
        $query = $this->db->get_where('landrecords', array('LHID' => $LHID));
        return $query->row();
    }

    public function update_record($LHID, $data) {
        $this->db->where('LHID', $LHID);
        return $this->db->update('landrecords', $data);
    }

    public function insert_record($data) {
        return $this->db->insert('landrecords', $data);
    }

    public function deleteRecord($id) {
        $this->db->where('LHID', $id);
        $this->db->delete('landrecords');
        return $this->db->affected_rows() > 0;
    }

    public function get_tables() {
        $query = $this->db->query("SHOW TABLES");
        return $query->result_array();
    }

    public function get_table_data($table_name) {
        $query = $this->db->get($table_name);
        return $query->result_array();
    }
}
