<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'landholding/view';

$route['Landholding/edit_record/(:any)'] = 'Landholding/edit_record/$1';
$route['Landholding/add_record/(:any)'] = 'Landholding/add_record/$1';
$route['landrecords/delete/(:any)'] = 'landholding/delete/$1';

$route['landholding/view_tables'] = 'landholding/view_tables'; 
$route['download'] = 'landholding/view_tables'; 

$route['landholding/download_excel/(:any)'] = 'landholding/download_excel/$1';

$route['landholding/upload_form/(:any)'] = 'landholding/upload_form/$1';

$route['(:any)'] = 'landholding/view/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;