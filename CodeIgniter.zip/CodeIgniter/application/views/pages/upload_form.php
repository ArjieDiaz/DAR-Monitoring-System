<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database-like Table with Vuetify</title>
    <link href="https://cdn.jsdelivr.net/npm/vuetify@2.5.9/dist/vuetify.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font/css/materialdesignicons.min.css" rel="stylesheet">
    <style>
        .table-action-buttons {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }

        .yellow-header .v-data-table-header th {
            background-color: yellow !important;
        }
    </style>
</head>

<body>
    <div id="app">
        <v-app>
            <v-container fluid>
                <v-row align="center">
                    <v-col cols="auto">
                        <v-text-field v-model="search" label="Search" prepend-icon="mdi-magnify"></v-text-field>
                    </v-col>
                    <v-col cols="auto">
                        <v-btn small @click="openDialog" color="blue darken-2" dark fab>
                            <v-icon>mdi-plus</v-icon>
                        </v-btn>
                        <v-btn small @click="openColumnDialog" color="yellow darken-2" dark fab>
                            <v-icon>mdi-cog</v-icon>
                        </v-btn>
                    </v-col>
                </v-row>

                <v-data-table :headers="visibleHeaders" :items="filteredItems" item-key="id" class="yellow-header">
                    <template v-slot:item="{ item }">
                        <tr>
                            <td v-for="header in visibleHeaders" :key="header.value" v-if="header.visible">
                                {{ item[header.value] }}
                            </td>
                            <td class="table-action-buttons p-2">
                                <v-btn small @click="editItem(item)" color="green" dark fab>
                                    <v-icon small>mdi-pencil</v-icon>
                                </v-btn>
                                <v-btn small @click="deleteItem(item.id)" color="red" dark fab>
                                    <v-icon small>mdi-delete</v-icon>
                                </v-btn>
                            </td>
                        </tr>
                    </template>
                </v-data-table>
            </v-container>

            <v-dialog v-model="dialog">
                <v-card>
                    <v-card-title>
                        <span class="headline">{{ editMode ? 'Edit Data' : 'Add Data' }}</span>
                    </v-card-title>
                    <v-card-text>
                        <v-form @submit.prevent="submitData">
                            <v-container>
                                <v-row>
                                    <v-col v-for="field in headers" :key="field.value" cols="12" sm="6" md="3">
                                        <v-text-field v-model="currentItem[field.value]" :label="field.text"></v-text-field>
                                    </v-col>
                                </v-row>
                            </v-container>
                            <v-btn type="submit" color="primary">{{ editMode ? 'Update' : 'Submit' }}</v-btn>
                        </v-form>
                    </v-card-text>
                </v-card>
            </v-dialog>

            <v-dialog v-model="columnDialog">
                <v-card>
                    <v-card-title>
                        <span class="headline">Select Columns</span>
                    </v-card-title>
                    <v-card-text>
                        <v-container fluid>
                            <v-row dense>
                                <v-col v-for="header in headers" :key="header.value" cols="6" md="1">
                                    <v-checkbox v-model="header.visible" :label="header.text"></v-checkbox>
                                </v-col>
                            </v-row>
                        </v-container>
                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn color="primary" text @click="columnDialog = false">Close</v-btn>
                    </v-card-actions>
                </v-card>
            </v-dialog>

            <v-snackbar v-model="snackbar" :color="snackbarColor" top timeout="3000" rounded>
                {{ snackbarText }}
                <v-btn color="white" text @click="snackbar = false">Close</v-btn>
            </v-snackbar>
        </v-app>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vuetify@2.5.9/dist/vuetify.min.js"></script>
    <script>
        new Vue({
            el: '#app',
            vuetify: new Vuetify(),
            data() {
                return {
                    headers: [],
                    items: [],
                    search: '',
                    currentItem: {},
                    dialog: false,
                    columnDialog: false,
                    snackbar: false,
                    snackbarText: '',
                    snackbarColor: '',
                    editMode: false
                };
            },
            created() {
                this.fetchData();
            },
            computed: {
                visibleHeaders() {
                    return this.headers.filter(header => header.visible);
                },
                filteredItems() {
                    return this.items.filter(item => Object.values(item).some(val =>
                        String(val).toLowerCase().includes(this.search.toLowerCase())
                    ));
                },
            },
            methods: {
                fetchData() {
                    fetch('./index.php/landholding/fetchdata')
                        .then(response => response.json())
                        .then(data => {
                            if (data.length > 0) {
                                this.headers = Object.keys(data[0]).map(key => ({
                                    text: key,
                                    value: key,
                                    visible: true 
                                }));
                            }
                            this.items = data;
                        })
                        .catch(error => {
                            this.showSnackbar('Error fetching data: ' + error.message, 'error');
                        });
                },
                openDialog() {
                    this.dialog = true;
                    this.editMode = false;
                    this.currentItem = {};
                },
                openColumnDialog() {
                    this.columnDialog = true;
                },
                editItem(item) {
                    this.dialog = true;
                    this.editMode = true;
                    this.currentItem = { ...item };
                },
                submitData() {
                    const url = this.editMode ? 'update_data.php' : 'insert_data.php';
                    fetch(url, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(this.currentItem)
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.message.includes("successfully")) {
                            this.fetchData();
                            this.dialog = false;
                            this.showSnackbar(data.message, 'success');
                        } else {
                            this.showSnackbar("Error: " + data.message, 'error');
                        }
                    })
                    .catch(error => {
                        this.showSnackbar("An error occurred while saving data: " + error.message, 'error');
                    });
                },
                deleteItem(id) {
                    fetch('delete_data.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.message.includes("successfully")) {
                            this.fetchData();
                            this.showSnackbar(data.message, 'success');
                        } else {
                            this.showSnackbar("Error: " + data.message, 'error');
                        }
                    })
                    .catch(error => {
                        this.showSnackbar("An error occurred while deleting data: " + error.message, 'error');
                    });
                },
                showSnackbar(message, color) {
                    this.snackbarText = message;
                    this.snackbarColor = color;
                    this.snackbar = true;
                }
            }
        });
    </script>
</body>

</html>
