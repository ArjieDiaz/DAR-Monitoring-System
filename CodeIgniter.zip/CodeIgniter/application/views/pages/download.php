<?php
require_once 'vendor/autoload.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <!-- Include Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <h2 class="text-2xl font-bold mb-4"><?php echo $title; ?></h2>
        <table class="w-full">
            <thead>
                <tr>
                    <th class="py-2">Table Name</th>
                    <th class="py-2">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($tables)): ?>
                    <?php foreach ($tables as $table): ?>
                        <tr>
                            <td class="py-2"><?php echo reset($table); ?></td>
                            <td class="py-2">
                                <a href="<?php echo base_url('landholding/download_table/' . reset($table)); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Download Excel</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="2" class="py-2">No tables found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
