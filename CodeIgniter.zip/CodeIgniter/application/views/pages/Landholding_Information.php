<!DOCTYPE html>
<html lang="en">
<head>
<title>Search</title>
<link href="https://cdn.jsdelivr.net/npm/vuetify@2.6.3/dist/vuetify.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>

<body class="bg-gray-100">

<div id="app" style="padding-left: 64px;">

<!-- Application Bar -->
    <div class=" text-white p-4" style="background: linear-gradient(90deg, #023020 20%, rgba(6,121,24,1) 50%, rgba(6,120,24,1) 50%, rgba(18,51,23,1) 97%); z-index: 1;">

        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <span class="font-semibold text-lg">LandOwner</span>
            </div>
            <div class="flex items-center">
                <form id="searchForm" method="GET" action="">
                    <input type="text" id="searchInput" name="searchTerm" class="px-3 py-1 bg-white-600 rounded-md text-white focus:outline-none focus:bg-white-700" placeholder="Search...">
                    <button type="submit" class="ml-2 bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-md text-white">Search</button>
                </form>
            </div>
        </div>

    </div>
<div class="flex">

<!-- Vertical Tabs -->
    <div class="w-1/1 bg-gray-200 p-4">
        <div v-for="(item, index) in items" :key="index" @click="tab = index" :class="['cursor-pointer', tab === index ? 'bg-blue-100 text-blue-500' : 'bg-gray-200 text-gray-700', 'flex items-center justify-start p-2 rounded-md mb-2']">
            <i class="material-icons mr-2">person</i>
            <span class="ml-2">{{ item.title }}</span>
        </div>
    </div>
    <!-- Tab Content -->
    <div class="w-3/4 p-4">
        <v-expand-transition>
            <div v-if="tab === index" v-for="(item, index) in items" :key="index">
                <div class="flex items-center justify-center bg-green-200 p-4 rounded shadow"   >
                    <span class="text-3xl font-bold uppercase">{{ item.title }}</span>
                </div>
                <div class="mt-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div v-for="(data, key) in item.data" :key="key" class="p-4 bg-white rounded shadow">
                            <p class="text-xs text-gray-500">{{ key }}</p>
                            <h2 :class="{
                                    'text-lg font-semibold mb-2': data !== 'Not Available' && data !== '',
                                    'text-red-500 font-semibold mb-2': data === 'Not Available' || data === ''
                                }">
                                {{ data !== '' ? data : 'Empty!' }}
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </v-expand-transition>
    </div>

</div>
</div>
<!-- Include Vue.js -->
<script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js"></script>
<script src="<?= base_url('assets/js/my-component.js') ?>"></script>

</body>
</html>
