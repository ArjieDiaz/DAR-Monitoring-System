<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/vuetify@1.5.14/dist/vuetify.min.css'>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<div id="app" >

  <div class=" text-white p-4" style="background: linear-gradient(90deg, #023020 20%, rgba(6,121,24,1) 50%, rgba(6,120,24,1) 50%, rgba(18,51,23,1) 97%); z-index: 1;">
    <div class="flex items-center justify-between">            
        <div class="flex items-center">
            <span class="font-semibold text-lg">LandOwner</span>
        </div>  
    </div>
  </div>

  <!-- Application Bar -->
    <div class="flex">
    <!-- Vertical Tabs -->
        <div class="w-1/1 p-4">

            <!-- Search Area -->
            <div class="mt-10 bg-green-100 rounded-full p-1 mt-1 cursor-pointer transition duration-300 ease-in-out hover:bg-purple-200">
              <div class="relative">
                <input type="text" v-model="search" placeholder="Search..." class="rounded-full py-2 px-4 pr-10 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent w-full max-w-md">
                <div class="absolute inset-y-0 right-0 flex items-center pr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-gray-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M14.293 13.707a1 1 0 1 1-1.414 1.414l-3.792-3.792a5 5 0 1 1 1.414-1.414l3.792 3.792zM13 8a5 5 0 1 0-10 0 5 5 0 0 0 10 0z" clip-rule="evenodd" />
                  </svg>
                </div>
              </div>
            </div>

          <!-- List Items -->
            <div v-for="(item, index) in items" :key="index" @click="tab = index" class="flex items-center justify-between bg-yellow-100 rounded-l-full p-5 mt-3 cursor-pointer transition duration-300 ease-in-out hover:bg-yellow-200">
                <div class="flex items-center">
                  <i class="material-icons text-lg text-yellow-600 mr-2">person</i>
                  <span class="text-gray-800">{{ item.title }}</span>
                </div>
                <i class="material-icons text-gray-400">chevron_right</i>
            </div>
        </div>
        
        <!-- Tab Content -->
        <div class="w-3/4 p-5 mt-3">
          <div v-for="(item, index) in items" :key="index">
            <div v-if="tab === index">
              <div class="flex items-center justify-center bg-green-200 p-4 rounded-full">
                <span class="text-4xl font-bold uppercase">{{ item.title }}</span>
              </div>
              <div class="mt-4">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-1 bg-white rounded-sm">
                  <div v-for="(data, key) in item.data" :key="key" class="p-4">
                    <div v-if="filteredLandholdings.length > 0 && Object.keys(filteredLandholdings[0]).includes(key)" class="mb-2">
                      <p class="text-xl text-gray-500 mb-1">{{ key }}</p>
                      <div :class="{
                              'text-xl font-semibold mb-2': filteredLandholdings[0][key] !== 'Not Available' && filteredLandholdings[0][key] !== '',
                              'text-red-500 font-semibold mb-2': filteredLandholdings[0][key] === 'Not Available' || filteredLandholdings[0][key] === ''
                            }">
                        {{ filteredLandholdings[0][key] !== '' ? filteredLandholdings[0][key] : 'Empty!' }}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/vue@2"></script>
<script src='https://cdn.jsdelivr.net/npm/vuetify@1.5.14/dist/vuetify.min.js'></script>  
<script src="<?= base_url('assets/js/my-component.js') ?>"></script>
