<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Record</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container" style="padding-bottom: 50px;">
    <h2 class="mt-5">Add New Record</h2>
    <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success">
            <?php echo $this->session->flashdata('success'); ?>
        </div>
    <?php endif; ?>
    <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger">
            <?php echo $this->session->flashdata('error'); ?>
        </div>
    <?php endif; ?>
    <form method="post" action="<?= base_url('Landholding/add_record#section-1') ?>">
        <div class="row">
                            <h4 class="mb-3">Identity Information</h4>
                            <div class="col-md-6 form-group mb-3">
                                <label for="LHID" class="form-label"><i class="bi bi-person-badge"></i> LHID</label>
                                <input type="text" name="LHID" id="LHID" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="TitleNumber" class="form-label"><i class="bi bi-card-text"></i> Title Number</label>
                                <input type="text" name="TitleNumber" id="TitleNumber" class="form-control">
                            </div>
                        </div>

                        <!-- Owner Information -->
                        <div class="row">
                            <h4 class="mb-3">Owner Information</h4>
                            <div class="col-md-6 form-group mb-3">
                                <label for="LOName" class="form-label"><i class="bi bi-person"></i> LO Name</label>
                                <input type="text" name="LOName" id="LOName" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="MOA" class="form-label"><i class="bi bi-file-earmark-text"></i> MOA</label>
                                <input type="text" name="MOA" id="MOA" class="form-control">
                            </div>
                        </div>

                        <!-- Location Information -->
                        <div class="row">
                            <h4 class="mb-3">Location Information</h4>
                            <div class="col-md-6 form-group mb-3">
                                <label for="Phase" class="form-label"><i class="bi bi-geo-alt"></i> Phase</label>
                                <input type="text" name="Phase" id="Phase" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="RegionName" class="form-label"><i class="bi bi-map"></i> Region Name</label>
                                <input type="text" name="RegionName" id="RegionName" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="ProvinceName" class="form-label"><i class="bi bi-geo"></i> Province Name</label>
                                <input type="text" name="ProvinceName" id="ProvinceName" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="MCDName" class="form-label"><i class="bi bi-building"></i> MCD Name</label>
                                <input type="text" name="MCDName" id="MCDName" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="BarangayName" class="form-label"><i class="bi bi-house-door"></i> Barangay Name</label>
                                <input type="text" name="BarangayName" id="BarangayName" class="form-control">
                            </div>
                        </div>

                        <!-- Survey Information -->
                        <div class="row">
                            <h4 class="mb-3">Survey Information</h4>
                            <div class="col-md-6 form-group mb-3">
                                <label for="SurveyStatus" class="form-label"><i class="bi bi-list-check"></i> Survey Status</label>
                                <input type="text" name="SurveyStatus" id="SurveyStatus" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="SurveyNumber" class="form-label"><i class="bi bi-hash"></i> Survey Number</label>
                                <input type="text" name="SurveyNumber" id="SurveyNumber" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="SurveyStatusDesc" class="form-label"><i class="bi bi-chat-square-text"></i> Survey Status Description</label>
                                <input type="text" name="SurveyStatusDesc" id="SurveyStatusDesc" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="SurveyStatusDate" class="form-label"><i class="bi bi-calendar-date"></i> Survey Status Date</label>
                                <input type="text" name="SurveyStatusDate" id="SurveyStatusDate" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="SurveyRemarks" class="form-label"><i class="bi bi-pencil-square"></i> Survey Remarks</label>
                                <input type="text" name="SurveyRemarks" id="SurveyRemarks" class="form-control">
                            </div>
                        </div>

                        <!-- Area Information -->
                        <div class="row">
                            <h4 class="mb-3">Area Information</h4>
                            <div class="col-md-6 form-group mb-3">
                                <label for="TotalArea" class="form-label"><i class="bi bi-arrows-fullscreen"></i> Total Area</label>
                                <input type="text" name="TotalArea" id="TotalArea" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="ComputedArea" class="form-label"><i class="bi bi-calculator"></i> Computed Area</label>
                                <input type="text" name="ComputedArea" id="ComputedArea" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="DistributedArea" class="form-label"><i class="bi bi-diagram-3"></i> Distributed Area</label>
                                <input type="text" name="DistributedArea" id="DistributedArea" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="LotNumber" class="form-label"><i class="bi bi-grid"></i> Lot Number</label>
                                <input type="text" name="LotNumber" id="LotNumber" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="NewLandSize" class="form-label"><i class="bi bi-rulers"></i> New Land Size</label>
                                <input type="text" name="NewLandSize" id="NewLandSize" class="form-control">
                            </div>
                        </div>

                        <!-- Status Information -->
                        <div class="row">
                            <h4 class="mb-3">Status Information</h4>
                            <div class="col-md-6 form-group mb-3">
                                <label for="CurrentStatus" class="form-label"><i class="bi bi-info-circle"></i> Current Status</label>
                                <input type="text" name="CurrentStatus" id="CurrentStatus" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="CurrentStatusDesc" class="form-label"><i class="bi bi-info-square"></i> Current Status Description</label>
                                <input type="text" name="CurrentStatusDesc" id="CurrentStatusDesc" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="ClaimFolderStatusDesc" class="form-label"><i class="bi bi-folder"></i> Claim Folder Status Description</label>
                                <input type="text" name="ClaimFolderStatusDesc" id="ClaimFolderStatusDesc" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="ClaimFolderStatusDate" class="form-label"><i class="bi bi-calendar-check"></i> Claim Folder Status Date</label>
                                <input type="text" name="ClaimFolderStatusDate" id="ClaimFolderStatusDate" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="ClaimFolderRemarks" class="form-label"><i class="bi bi-journal-text"></i> Claim Folder Remarks</label>
                                <input type="text" name="ClaimFolderRemarks" id="ClaimFolderRemarks" class="form-control">
                            </div>
                        </div>

                        <!-- Target Year Information -->
                        <div class="row">
                            <h4 class="mb-3">Target Year Information</h4>
                            <div class="col-md-6 form-group mb-3">
                                <label for="CFDOCTargetYear" class="form-label"><i class="bi bi-calendar-event"></i> CFDOC Target Year</label>
                                <input type="text" name="CFDOCTargetYear" id="CFDOCTargetYear" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="SurveyTargetYear" class="form-label"><i class="bi bi-calendar"></i> Survey Target Year</label>
                                <input type="text" name="SurveyTargetYear" id="SurveyTargetYear" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="ValuationTargetYear" class="form-label"><i class="bi bi-calendar-range"></i> Valuation Target Year</label>
                                <input type="text" name="ValuationTargetYear" id="ValuationTargetYear" class="form-control">
                            </div>
                            <div class="col-md-6 form-group mb-3">
                                <label for="RegistrationTargetYear" class="form-label"><i class="bi bi-calendar2-check"></i> Registration Target Year</label>
                                <input type="text" name="RegistrationTargetYear" id="RegistrationTargetYear" class="form-control">
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="text-center mt-8">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                        
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
