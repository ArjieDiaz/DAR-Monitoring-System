    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/vuetify@1.5.14/dist/vuetify.min.css'>
    <link rel="stylesheet" href="<?= base_url('assets/css/Landholding_css.css') ?>">
    <div id="app" class="z-1">
        <v-app id="inspire" >
            <v-toolbar dark color="#144c8c" style="background: linear-gradient(90deg, #023020 20%, rgba(6,121,24,1) 50%, rgba(6,120,24,1) 50%, rgba(18,51,23,1) 97%); z-index: 1;">
                <v-toolbar-title class="white--text">Landholding Information</v-toolbar-title>
                <v-spacer></v-spacer>
                <v-text-field v-model="search" append-icon="search" label="Search" single-line hide-details></v-text-field>
            </v-toolbar>
            <v-layout v-resize="onResize" column>
                <v-data-table :headers="headers" :items="landholdings" :search="search" :pagination.sync="pagination" :hide-headers="isMobile" :class="{mobile: isMobile}">
                    <template slot="items" slot-scope="props">
                        <tr v-if="!isMobile">
                            <td class="text-xs-left border border-black">{{ props.item.LHID }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.TitleNumber }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.LOName }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.MOA }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.Phase }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.RegionName }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.ProvinceName }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.MCDName }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.BarangayName }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.SurveyStatus }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.TargetYear }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.PipelineYear }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.problematic }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.TotalArea }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.ComputedArea }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.DistributedArea }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.SurveyNumber }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.LotNumber }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.CARPable }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.NONCARPable }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.CurrentStatus }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.CurrentStatusDesc }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.NewLandSize }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.CFDOCTargetYear }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.SurveyTargetYear }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.ValuationTargetYear }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.RegistrationTargetYear }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.ClaimFolderStatusDesc }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.ClaimFolderStatusDate }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.ClaimFolderRemarks }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.SurveyStatusDesc }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.SurveyStatusDate }}</td>
                            <td class="text-xs-left border border-black">{{ props.item.SurveyRemarks }}</td>
                        </tr>
                        <tr v-else>
                            <td>
                            <ul class="flex-content">
                                <li class="flex-item" data-label="LHID">{{ props.item.LHID }}</li>
                                <li class="flex-item" data-label="Title No">{{ props.item.TitleNo }}</li>
                                <li class="flex-item" data-label="Landowner">{{ props.item.Landowner }}</li>
                                <li class="flex-item" data-label="MOA">{{ props.item.MOA }}</li>
                                <li class="flex-item" data-label="Projected Month of Delivery">{{ props.item.ProjectedMonthOfDelivery }}</li>
                                <li class="flex-item" data-label="Region">{{ props.item.Region }}</li>
                                <li class="flex-item" data-label="Province">{{ props.item.Province }}</li>
                                <li class="flex-item" data-label="Municipality">{{ props.item.Municipality }}</li>
                                <li class="flex-item" data-label="Barangay">{{ props.item.Barangay }}</li>
                                <li class="flex-item" data-label="DARPO Survey Status">{{ props.item.DARPOSurveyStatus }}</li>
                                <li class="flex-item" data-label="Target Year">{{ props.item.TargetYear }}</li>
                                <li class="flex-item" data-label="Indicate Quarter Target">{{ props.item.IndicateQuarterTarget }}</li>
                                <li class="flex-item" data-label="Schedule of FI">{{ props.item.ScheduleOfFI }}</li>
                                <li class="flex-item" data-label="Area">{{ props.item.Area }}</li>
                                <li class="flex-item" data-label="Computed Area">{{ props.item.ComputedArea }}</li>
                                <li class="flex-item" data-label="Distributed Area">{{ props.item.DistributedArea }}</li>
                                <li class="flex-item" data-label="SURVEY Sched">{{ props.item.SURVEYSched }}</li>
                                <li class="flex-item" data-label="Title No">{{ props.item.TitleNo }}</li>
                                <li class="flex-item" data-label="Area">{{ props.item.Area }}</li>
                                <li class="flex-item" data-label="MOA">{{ props.item.MOA }}</li>
                                <li class="flex-item" data-label="Current Status">{{ props.item.CurrentStatus }}</li>
                                <li class="flex-item" data-label="Remarks">{{ props.item.Remarks }}</li>
                                <li class="flex-item" data-label="New Land Size">{{ props.item.NewLandSize }}</li>
                                <li class="flex-item" data-label="CFDOC Target Year">{{ props.item.CFDOCTargetYear }}</li>
                                <li class="flex-item" data-label="Survey Target Year">{{ props.item.SurveyTargetYear }}</li>
                                <li class="flex-item" data-label="Valuation Target Year">{{ props.item.ValuationTargetYear }}</li>
                                <li class="flex-item" data-label="Registration Target Year">{{ props.item.RegistrationTargetYear }}</li>
                                <li class="flex-item" data-label="Claim Folder Status Desc">{{ props.item.ClaimFolderStatusDesc }}</li>
                                <li class="flex-item" data-label="Claim Folder Status Date">{{ props.item.ClaimFolderStatusDate }}</li>
                                <li class="flex-item" data-label="Claim Folder Remarks">{{ props.item.ClaimFolderRemarks }}</li>
                                <li class="flex-item" data-label="Survey Status Desc">{{ props.item.SurveyStatusDesc }}</li>
                                <li class="flex-item" data-label="Survey Status Date">{{ props.item.SurveyStatusDate }}</li>
                                <li class="flex-item" data-label="Survey Remarks">{{ props.item.SurveyRemarks }}</li>
                            </ul>
                            </td>
                        </tr>
                    </template>
                    <v-alert slot="no-results" :value="true" color="error" icon="warning">
                        Your search for "{{ search }}" found no results.
                    </v-alert>
                </v-data-table>
            </v-layout>
        </v-app>
    </div>
    
    <script>
export default {
    // Other component options

    methods: {
        isColumnEmpty(value) {
            // Check if the column value is empty
            return !value || value.trim() === '';
        }
    }
}
</script>

    
    <script src='https://cdn.jsdelivr.net/npm/vue/dist/vue.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/vuetify@1.5.14/dist/vuetify.min.js'></script>
    <script src="<?= base_url('assets/js/Landholding_js.js') ?>"></script>