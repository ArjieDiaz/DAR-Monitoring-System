<h2 style="background-color: red;"><?= $title ?></h2>
<?php foreach($posts as $post) : ?>
    <div> 
        <h3><?php echo $post['title']; ?></h3>
        <small>Posted on: <?php echo $post['created_at']; ?></small>
        <?php echo $post['body']; ?>
    </div>
<?php endforeach; ?>
