<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/style.css">
</head>
    <body style="padding-left: 64px;">

    <div class="area"></div>
    <nav class="main-menu">
    <img src="https://www.dar.gov.ph/wp-content/uploads/2024/11/dar-logo-100px.png" alt="Logo" width="60" height="60" style="padding-left: 10px; padding-top: 10px;">       
            <ul >              
                <li>                    
                    <a href="<?php echo base_url(); ?>">
                        <i class="fa fa-home fa-2x"></i>
                        <span class="nav-text">
                           Dashboard
                        </span>
                    </a>
                  
                </li>
                <li class="has-subnav">
                    <a href="<?php echo base_url(); ?>Landholding_Information">
                        <i class="fa fa-users fa-2x"></i>
                        <span class="nav-text">
                            LandHolding Info
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="<?php echo base_url(); ?>LandholdingInformation">
                        <i class="fa fa-info-circle fa-2x"></i>
                        <span class="nav-text">
                            LandHolding Details
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="<?php echo base_url(); ?>Landholding_Information">
                       <i class="fa fa-comments fa-2x"></i>
                        <span class="nav-text">
                            User Profile
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="#">
                       <i class="fa fa-camera-retro fa-2x"></i>
                        <span class="nav-text">
                            Survey Photos
                        </span>
                    </a>
                   
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-film fa-2x"></i>
                        <span class="nav-text">
                            Surveying Tutorials
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-book fa-2x"></i>
                        <span class="nav-text">
                           Surveying Jobs
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                       <i class="fa fa-cogs fa-2x"></i>
                        <span class="nav-text">
                            Tools & Resources
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                        <i class="fa fa-map-marker fa-2x"></i>
                        <span class="nav-text">
                            Member Map
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                       <i class="fa fa-info fa-2x"></i>
                        <span class="nav-text">
                            Documentation
                        </span>
                    </a>
                </li>
            </ul>
        </nav>
