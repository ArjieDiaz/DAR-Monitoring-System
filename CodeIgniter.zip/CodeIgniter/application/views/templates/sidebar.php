<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/style.css">
</head>
<body>
    <div class="area"></div>
    <nav class="main-menu">
    <img src="https://www.dar.gov.ph/assets/images/logo.svg" alt="Logo" width="60" height="60" style="padding-left: 10px; padding-top: 10px;">       
            <ul >              
                <li>                    
                    <a href="<?php echo base_url(); ?>Landholding_Information">
                        <i class="fa fa-home fa-2x"></i>
                        <span class="nav-text">
                           Landholding Information
                        </span>
                    </a>
                  
                </li>
                <li class="has-subnav">
                    <a href="<?php echo base_url(); ?>LandholdingInformation">
                        <i class="fa fa-globe fa-2x"></i>
                        <span class="nav-text">
                            Landholding_Information
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="<?php echo base_url(); ?>Landholding_Information">
                       <i class="fa fa-comments fa-2x"></i>
                        <span class="nav-text">
                            User Profile
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="#">
                       <i class="fa fa-camera-retro fa-2x"></i>
                        <span class="nav-text">
                            Survey Photos
                        </span>
                    </a>
                   
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-film fa-2x"></i>
                        <span class="nav-text">
                            Surveying Tutorials
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-book fa-2x"></i>
                        <span class="nav-text">
                           Surveying Jobs
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                       <i class="fa fa-cogs fa-2x"></i>
                        <span class="nav-text">
                            Tools & Resources
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                        <i class="fa fa-map-marker fa-2x"></i>
                        <span class="nav-text">
                            Member Map
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                       <i class="fa fa-info fa-2x"></i>
                        <span class="nav-text">
                            Documentation
                        </span>
                    </a>
                </li>
            </ul>

            <ul class="logout">
                <li>
                   <a href="#">
                         <i class="fa fa-power-off fa-2x"></i>
                        <span class="nav-text">
                            Logout
                        </span>
                    </a>
                </li>  
            </ul>
        </nav>
</body>
</html>