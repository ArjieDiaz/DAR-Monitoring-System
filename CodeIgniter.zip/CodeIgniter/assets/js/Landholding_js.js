new Vue({
    el: '#app',
    data: () => ({
        pagination: {
            sortBy: 'LHID' // Update default sorting column
        },
        selected: [],
        search: '',
        isMobile: false,
        headers: [
            { text: 'LHID', align: 'left', value: 'LHID' },
            { text: 'TitleNumber', value: 'TitleNumber' },
            { text: 'LOName', value: 'LOName' },
            { text: 'MOA', value: 'MOA' },
            { text: 'Phase', value: 'Phase' },
            { text: 'RegionName', value: 'RegionName' },
            { text: 'ProvinceName', value: 'ProvinceName' },
            { text: 'MCDName', value: 'MCDName' },
            { text: 'BarangayName', value: 'BarangayName' },
            { text: 'SurveyStatus', value: 'SurveyStatus' },
            { text: 'TargetYear', value: 'TargetYear' },
            { text: 'PipelineYear', value: 'PipelineYear' },
            { text: 'problematic', value: 'problematic' },
            { text: 'TotalArea', value: 'TotalArea' },
            { text: 'ComputedArea', value: 'ComputedArea' },
            { text: 'DistributedArea', value: 'DistributedArea' },
            { text: 'SurveyNumber', value: 'SurveyNumber' },
            { text: 'LotNumber', value: 'LotNumber' },
            { text: 'CARPable', value: 'CARPable' },
            { text: 'NONCARPable', value: 'NONCARPable' },
            { text: 'CurrentStatus', value: 'CurrentStatus' },
            { text: 'CurrentStatusDesc', value: 'CurrentStatusDesc' },
            { text: 'NewLandSize', value: 'NewLandSize' },
            { text: 'CFDOCTargetYear', value: 'CFDOCTargetYear' },
            { text: 'SurveyTargetYear', value: 'SurveyTargetYear' },
            { text: 'ValuationTargetYear', value: 'ValuationTargetYear' },
            { text: 'RegistrationTargetYear', value: 'RegistrationTargetYear' },
            { text: 'ClaimFolderStatusDesc', value: 'ClaimFolderStatusDesc' },
            { text: 'ClaimFolderStatusDate', value: 'ClaimFolderStatusDate' },
            { text: 'ClaimFolderRemarks', value: 'ClaimFolderRemarks' },
            { text: 'SurveyStatusDesc', value: 'SurveyStatusDesc' },
            { text: 'SurveyStatusDate', value: 'SurveyStatusDate' },
            { text: 'SurveyRemarks', value: 'SurveyRemarks' }
        ],
        landholdings: [] // Changed variable name to match the new table name
    }),
    methods: {
        onResize() {
            this.isMobile = window.innerWidth < 769;
        },
        toggleAll() {
            this.selected = this.selected.length ? [] : this.landholdings.slice();
        },
        changeSort(column) {
            if (this.pagination.sortBy === column) {
                this.pagination.descending = !this.pagination.descending;
            } else {
                this.pagination.sortBy = column;
                this.pagination.descending = false;
            }
        },
        fetchData() {
            fetch('./index.php/landholding/fetchdata') // Update endpoint URL
                .then(response => response.json())
                .then(data => {
                    this.landholdings = data;
                })
                .catch(error => console.error('Error fetching data:', error));
        }
    },
        created() {
            // Fetch data from PHP script
            this.fetchData();
        }
});