new Vue({
  el: '#app',
  data: () => ({
    search: '',
    tab: 0,
    items: [
      {
        title: 'Identification and Location Data',
        data: {
          LHID: '',
          TitleNumber: '',
          LOName: '',
          RegionName: '',
          ProvinceName: '',
          MCDName: '',
          BarangayName: ''
        }
      },
      {
        title: 'Geographical Data',
        data: {
          Phase: '',
          MOA: '',
          TargetYear: '',
          PipelineYear: ''
        }
      },
      {
        title: 'Land Area Information',
        data: {
          TotalArea: '',
          ComputedArea: '',
          DistributedArea: '',
          NewLandSize: ''
        }
      },
      {
        title: 'Survey and Legal Status',
        data: {
          SurveyNumber: '',
          LotNumber: '',
          CARPable: '',
          NONCARPable: '',
          SurveyStatus: '',
          SurveyStatusDesc: '',
          SurveyRemarks: '',
          SurveyTargetYear: ''
        }
      },
      {
        title: 'Current Status and Description',
        data: {
          CurrentStatus: '',
          CurrentStatusDesc: '',
          ClaimFolderStatusDesc: '',
          ClaimFolderStatusDate: '',
          ClaimFolderRemarks: ''
        }
      },
      {
        title: 'Target Years for Different Processes',
        data: {
          CFDOCTargetYear: '',
          ValuationTargetYear: '',
          RegistrationTargetYear: ''
        }
      },
      {
        title: 'Miscellaneous/Additional Information',
        data: {
          problematic: ''
        }
      }
    ],
    landholdings: [],
  }),
  computed: {
    filteredLandholdings() {
      const searchTerm = this.search.toLowerCase();
      return this.landholdings.filter(landholding =>
        Object.values(landholding).some(value =>
          value.toString().toLowerCase().includes(searchTerm)
        )
      );
    }
  },
  methods: {
    fetchData() {
      fetch('./index.php/landholding/fetchdata')
        .then(response => {
          // Added error handling for network response
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then(data => {
          this.landholdings = data;
          // Separated logic to populate initial data into its own method
          this.populateInitialData(data);
        })
        .catch(error => console.error('Error fetching data:', error));
    },
    populateInitialData(fetchedData) {
      // Improved readability by using forEach and checking for data keys
      Object.keys(this.items[0].data).forEach(key => {
        if (fetchedData.hasOwnProperty(key)) {
          this.items[0].data[key] = fetchedData[key];
        }
      });
    }
  },
  created() {
    this.fetchData();
  }
});
