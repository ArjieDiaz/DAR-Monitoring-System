new Vue({
    el: '#app',
    data() {
        return {
            tab: 0,
            items: [
                    {
                        title: 'Identification and Location Data',
                        data: {
                            'LHID': '',
                            'TitleNumber': '',
                            'LOName': '',
                            'RegionName': '',
                            'ProvinceName': '',
                            'MCDName': '',
                            'BarangayName': ''
                        }
                    },
                    {
                        title: 'Geographical Data',
                        data: {
                            'Phase': '',
                            'MOA (Memorandum of Agreement)': '',
                            'TargetYear': '',
                            'PipelineYear': ''
                        }
                    },
                    {
                        title: 'Land Area Information',
                        data: {
                            'TotalArea': '',
                            'ComputedArea': '',
                            'DistributedArea': '',
                            'NewLandSize': ''
                        }
                    },
                    {
                        title: 'Survey and Legal Status',
                        data: {
                            'SurveyNumber': '',
                            'LotNumber': '',
                            'CARPable': '',
                            'NONCARPable': '',
                            'SurveyStatus': '',
                            'SurveyStatusDesc': '',
                            'NONCARPable': '',
                            'SurveyRemarks': '',
                            'SurveyTargetYear': ''
                        }
                    },
                    {
                        title: 'Current Status and Description',
                        data: {
                            'CurrentStatus': '',
                            'CurrentStatusDesc': '',
                            'ClaimFolderStatusDesc': '',
                            'ClaimFolderStatusDate': '',
                            'ClaimFolderRemarks': ''
                        }
                    },
                    {
                        title: 'Target Years for Different Processes',
                        data: {
                            'CFDOCTargetYear': '',
                            'ValuationTargetYear': '',
                            'RegistrationTargetYear': ''
                        }
                    },
                    {
                        title: 'Miscellaneous/Additional Information',
                        data: {
                            'Problematic': ''
                        }
                    }
                ]
        };
    },
    mounted() {
        this.fetchData(); // Call the fetchData method when the component is mounted
    },
    methods: {
        fetchData() {
            fetch('./index.php/landholding/fetchdata') // Update endpoint URL
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        // Assuming LHID is the first item in the fetched data
                         this.items[0].data.LHID = data[0].LHID;
                        this.items[0].data.TitleNumber = data[0].TitleNumber;
                        this.items[0].data.LOName = data[0].LOName;
                        this.items[0].data.RegionName = data[0].RegionName;
                        this.items[0].data.ProvinceName = data[0].ProvinceName;
                        this.items[0].data.MCDName = data[0].MCDName;
                        this.items[0].data.BarangayName = data[0].BarangayName;
                        this.items[1].data.Phase = data[0].Phase;
                        this.items[1].data['MOA (Memorandum of Agreement)'] = data[0].MOA;
                        this.items[1].data.TargetYear = data[0].TargetYear;
                        this.items[1].data.PipelineYear = data[0].PipelineYear;
                        this.items[2].data.TotalArea = data[0].TotalArea;
                        this.items[2].data.ComputedArea = data[0].ComputedArea;
                        this.items[2].data.DistributedArea = data[0].DistributedArea;
                        this.items[2].data.NewLandSize = data[0].NewLandSize;
                        this.items[3].data.SurveyNumber = data[0].SurveyNumber;
                        this.items[3].data.LotNumber = data[0].LotNumber;
                        this.items[3].data.CARPable = data[0].CARPable;
                        this.items[3].data.NONCARPable = data[0].NONCARPable;
                        this.items[3].data.SurveyStatus = data[0].SurveyStatus;
                        this.items[3].data.SurveyStatusDesc = data[0].SurveyStatusDesc;
                        this.items[3].data.SurveyRemarks = data[0].SurveyRemarks;
                        this.items[3].data.SurveyTargetYear = data[0].SurveyTargetYear;
                        this.items[4].data.CurrentStatus = data[0].CurrentStatus;
                        this.items[4].data.CurrentStatusDesc = data[0].CurrentStatusDesc;
                        this.items[4].data.ClaimFolderStatusDesc = data[0].ClaimFolderStatusDesc;
                        this.items[4].data.ClaimFolderStatusDate = data[0].ClaimFolderStatusDate;
                        this.items[4].data.ClaimFolderRemarks = data[0].ClaimFolderRemarks;
                        this.items[5].data.CFDOCTargetYear = data[0].CFDOCTargetYear;
                        this.items[5].data.ValuationTargetYear = data[0].ValuationTargetYear;
                        this.items[5].data.RegistrationTargetYear = data[0].RegistrationTargetYear;
                        this.items[6].data.Problematic = data[0].Problematic;
                    }
                })
                .catch(error => console.error('Error fetching data:', error));
        }
    }
});
